// eslint-disable-next-line no-undef
module.exports = 'test-file-stub';