export const numberToFixed = (number: number, toFixed: number) => {
  return parseFloat(number.toFixed(toFixed));
};
