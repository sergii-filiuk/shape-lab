export * from './calculateRectanglesObb.ts';
