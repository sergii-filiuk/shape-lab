export * from './UpSlopeIcon.tsx';
