export * from './AlignHorizontalIcon.tsx';
