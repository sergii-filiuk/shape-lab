export * from './RotateAngleIcon.tsx';
