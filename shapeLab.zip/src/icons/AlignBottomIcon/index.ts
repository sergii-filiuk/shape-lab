export * from './AlignBottomIcon.tsx';
