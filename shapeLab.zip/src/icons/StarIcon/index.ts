export * from './StarIcon.tsx';
