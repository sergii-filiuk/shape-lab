export * from './ScaleIcon.tsx';
