export * from './MoveEntityAnchorcon.tsx';
