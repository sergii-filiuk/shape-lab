export * from './TriangleIcon.tsx';
