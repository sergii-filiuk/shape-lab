export * from './AlignLeftIcon.tsx';
