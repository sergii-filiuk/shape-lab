export * from './HorizontalScaleIcon.tsx';
