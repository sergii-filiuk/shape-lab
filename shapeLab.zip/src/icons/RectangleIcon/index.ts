export * from './RectangleIcon.tsx';
