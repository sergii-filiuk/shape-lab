export * from './AlignRightIcon.tsx';
