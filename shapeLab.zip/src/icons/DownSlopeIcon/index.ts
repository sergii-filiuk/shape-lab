export * from './DownSlopeIcon.tsx';
