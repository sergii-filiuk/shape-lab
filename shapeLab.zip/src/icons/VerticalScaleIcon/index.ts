export * from './VerticalScaleIcon.tsx';
