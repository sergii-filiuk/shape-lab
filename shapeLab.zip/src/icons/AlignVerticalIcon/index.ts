export * from './AlignVerticalIcon.tsx';
