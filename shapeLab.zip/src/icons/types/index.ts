export type IconProps = {
  className?: string;
  viewBox?: string;
};
