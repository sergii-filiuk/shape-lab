export * from './GeometryIcon.tsx';
