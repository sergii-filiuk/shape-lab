export * from './MoveEntityAnchor.tsx';
