export interface ToolProps {
  id: string;
  className?: string;
}
