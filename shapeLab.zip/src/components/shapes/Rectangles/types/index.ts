import { Shape } from '../../../../store/scenesStore/types';

export type RectanglesProps = {
  shapes: Shape[];
};
