export * from './Rectangles.tsx';
