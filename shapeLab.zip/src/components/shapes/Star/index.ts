export * from './Star.tsx';
