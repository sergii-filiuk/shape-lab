export * from './Triangle.tsx';
