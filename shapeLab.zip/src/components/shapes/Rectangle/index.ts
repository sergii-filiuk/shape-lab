export * from './Rectangle.tsx';
