import { Shape } from '../../../../store/scenesStore/types';

export type StarsProps = {
  shapes: Shape[];
};
