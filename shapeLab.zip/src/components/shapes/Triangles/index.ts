export * from './Triangles.tsx';
