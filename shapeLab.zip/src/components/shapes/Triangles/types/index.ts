import { Shape } from '../../../../store/scenesStore/types';

export type TrianglesProps = {
  shapes: Shape[];
};
