import { Shape } from '../../../../store/scenesStore/types';

export type CirclesProps = {
  shapes: Shape[];
};
