export const HOVER_FRAME_BORDER_COLOR = '#02b7fe';
