import { Editor } from '../Editor';

export const Dashboard = () => {
  return (
    <div className="grow relative w-full">
      <Editor />
    </div>
  );
};
